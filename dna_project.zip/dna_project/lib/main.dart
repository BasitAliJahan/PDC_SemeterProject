import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;

void main() {
  runApp(DnaCrimeApp());
}

class DnaCrimeApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "DNA Crime Investigation",
      theme: ThemeData(primarySwatch: Colors.blue),
      home: HomeScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

// =============================================
// HOME SCREEN
// =============================================
class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  TextEditingController patternCtrl = TextEditingController();
  bool loading = false;

  Future<List<Map<String, dynamic>>> loadDatabase() async {
    String content = await rootBundle.loadString('assets/database.txt');
    List<String> lines = content.split("\n");

    List<Map<String, dynamic>> profiles = [];

    for (String line in lines) {
      if (line.trim().isEmpty) continue;
      var parts = line.split("|");
      if (parts.length < 3) continue;

      profiles.add({
        "id": int.tryParse(parts[0]) ?? 0,
        "name": parts[1],
        "dna": parts[2],
      });
    }
    return profiles;
  }

  int levenshtein(String s, String t) {
    int n = s.length;
    int m = t.length;
    if (n == 0) return m;
    if (m == 0) return n;

    List<int> prev = List<int>.generate(m + 1, (i) => i);
    List<int> curr = List<int>.filled(m + 1, 0);

    for (int i = 1; i <= n; i++) {
      curr[0] = i;
      for (int j = 1; j <= m; j++) {
        int cost = s[i - 1] == t[j - 1] ? 0 : 1;
        int insert = curr[j - 1] + 1;
        int delete = prev[j] + 1;
        int replace = prev[j - 1] + cost;
        curr[j] = [insert, delete, replace].reduce((a, b) => a < b ? a : b);
      }
      List<int> temp = prev;
      prev = curr;
      curr = temp;
    }
    return prev[m];
  }

  Future<void> runMatching() async {
    String pattern = patternCtrl.text.trim();

    if (pattern.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Enter a DNA pattern first!")));
      return;
    }

    setState(() => loading = true);

    List<Map<String, dynamic>> db = await loadDatabase();

    List<Map<String, dynamic>> scored = [];

    for (var p in db) {
      String dna = p["dna"];
      int dist = levenshtein(pattern, dna);
      int matches = (pattern.length + dna.length) - dist;

      scored.add({
        "id": p["id"],
        "name": p["name"],
        "dna": dna,
        "distance": dist,
        "matches": matches,
      });
    }

    scored.sort((a, b) => b["matches"].compareTo(a["matches"]));

    List<Map<String, dynamic>> top5 = scored.take(5).toList();

    setState(() => loading = false);

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ResultScreen(pattern: pattern, results: top5),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("DNA Crime Investigation"),
        centerTitle: true,
      ),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            Text("Enter DNA Pattern:",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            TextField(
              controller: patternCtrl,
              decoration: InputDecoration(
                hintText: "Enter DNA sequence",
                border: OutlineInputBorder(),
              ),
              minLines: 1,
              maxLines: 3,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: loading ? null : runMatching,
              child: loading
                  ? CircularProgressIndicator(color: Colors.white)
                  : Text("Match DNA"),
            ),
          ],
        ),
      ),
    );
  }
}

// =============================================
// RESULT SCREEN
// =============================================
class ResultScreen extends StatelessWidget {
  final String pattern;
  final List<Map<String, dynamic>> results;

  ResultScreen({required this.pattern, required this.results});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Top 5 Suspects"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: ListView.builder(
          itemCount: results.length,
          itemBuilder: (_, index) {
            var r = results[index];
            return Card(
              child: ListTile(
                title: Text("${r['name']} (ID: ${r['id']})"),
                subtitle: Text(
                  "Matches: ${r['matches']}\nDistance: ${r['distance']}",
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
